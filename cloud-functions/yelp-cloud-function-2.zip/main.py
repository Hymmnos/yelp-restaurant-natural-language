import customfunctions
import pandas as pd
import gcsfs
import pubsub_publisher
from google.cloud import language

# topic to publish to trigger next Cloud Function
topic = 'demo-3-classification'

def process_sentiment(data, context):

    # Developer: Edit Here
    final_df = pd.read_csv("gs://YOUR-BUCKET/YOUR/DIRECTORIES/final_df.csv")

    # sentiment analysis
    final_df = customfunctions.multiprocess_sentiment(final_df,func = customfunctions.generate_sentiment)

    # Developer: Edit Here
    final_df.to_csv("gs://YOUR-BUCKET/YOUR/DIRECTORIES/final_df.csv")

    # trigger next Cloud Function
    pubsub_publisher.publish_topic(topic)









from google.cloud import pubsub_v1

# assign project id 
# Developer: Edit Here
project_id = "YOUR-ID"

# create publisher client
publisher = pubsub_v1.PublisherClient()

# function to publish topic to Cloud Pub/Sub to trigger next Cloud Function 
def publish_topic(topic):
	# create topic path 
	topic_path = publisher.topic_path(project_id, topic)

	# make pub sub data the same as topic, since we are just using it to trigger another cloud function 
	data = topic 
	data = data.encode('utf-8')

	# trigger pub sub 
	response = publisher.publish(topic_path, data=data)

	# wait for topic to be published
	response.result()
import multiprocessing as mp
import sys
from google.api_core.client_options import ClientOptions
from google.cloud import language
from google.cloud.language import enums
from google.cloud.language import types
import numpy as np
import pandas as pd

##################################################
#### Functions for Google's sentiment analysis ###
##################################################

# Instantiate a language client
language_client = language.LanguageServiceClient()

def analyze_sentiment(content, client=language_client):
    """function to return sentiment and magnitude from google api for single text string"""
    type_ = enums.Document.Type.PLAIN_TEXT
    # create document payload
    document = {'type': type_, 'content': content}

    try:
        # send request to natural language API
        response = client.analyze_sentiment(document)

        # return document sentiment
        sentiment = response.document_sentiment

        # save sentiment score
        score = sentiment.score

        # save sentiment magnitude
        magnitude = sentiment.magnitude

    except Exception as error:
        print(error)
        score = -99.0
        magnitude = -99.0 

    return score, magnitude 

def generate_sentiment(df,output):
    """execute analyze_sentiment() on each sentence in the dataframe, assign results to 
       new sentiment and magnitude columns in dataframe """
    df['sentiment_score'], df['sentiment_magnitude'] = zip(*df['review_text'].apply(analyze_sentiment))
    
    output.put(df)

    
def multiprocess_sentiment(df,func=generate_sentiment):
    """split the df into separate chunks and multiprocess sentiment on each chunk"""

    output = mp.Queue()
    
    processes = [mp.Process(target=func, args=(f, output)) for f in np.array_split(df, 10)]
    
    for p in processes:
        p.start()

    final_return = pd.concat([output.get() for p in processes])
    
    return final_return

import customfunctions
import pubsub_publisher
import pandas as pd
import gcsfs
import datetime as dt

# topic to publish to trigger next Cloud Function
topic = 'yelp-sentiment-analysis'

def scrape_and_clean(request):

    request_json = request.get_json(silent=True)
    request_args = request.args

    if request_args and 'zip' in request_args:
        zip_code = request_args['zip']
    elif request_json and 'zip' in request_json:
        zip_code = request_json['zip']
    else:
        return f"No field 'zip' found."

    # pull data
    final_df = customfunctions.scrape_main(zip_code)
    # clean up data
    final_df = customfunctions.clean_main(final_df)

    # add timestamp
    final_df['timestamp'] = dt.datetime.now()

    # Developer: Edit Here
    final_df.to_csv("gs://YOUR-BUCKET/YOUR/DIRECTORIES/final_df.csv")


    # trigger next Cloud Function
    pubsub_publisher.publish_topic(topic)
    
    return f"Assuming 'zip' is valid, data will be appended to BigQuery shortly."

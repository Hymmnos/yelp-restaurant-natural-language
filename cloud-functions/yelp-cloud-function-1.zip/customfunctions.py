import requests
import pandas as pd
import multiprocessing as mp
import numpy as np
from google.cloud import secretmanager

#####################################################
#### Function to get API key from secret manager ####
#####################################################

def access_secret_version(project_id, secret_id, version_id):
    """
    Access the payload for the given secret version if one exists. The version
    can be a version number as a string (e.g. "5") or an alias (e.g. "latest").
    """

    # Create the Secret Manager client.
    client = secretmanager.SecretManagerServiceClient()

    # Build the resource name of the secret version.
    name = client.secret_version_path(project_id, secret_id, version_id)

    # Access the secret version.
    api_key = client.access_secret_version(name)
    return api_key

# Developer: Edit Here
api_key = access_secret_version('YOUR-ID', 'Yelp-API', '1').payload.data.decode('UTF-8')

headers = {
    'Authorization': 'Bearer %s' % api_key,
}

##################################################
#### Function to pull restaurants by zip code ####
##################################################

def pull_businesses(zip_code,business_type='restaurants'):
    """pulls list of all businesses and relevant info with yelp api by zipcode """
    restaurant_url = "https://api.yelp.com/v3/businesses/search?categories=%s&location=%s" % (business_type,zip_code)
    # pull in list of restaurants and create dataframe
    restaurants = requests.get(restaurant_url,headers=headers)
    restaurant_df = pd.DataFrame(restaurants.json()['businesses'])
    [['name','categories','coordinates','display_phone','id','is_closed','location','rating','url']]    
    return restaurant_df

###################################################
#### Functions to full reviews for restaurants ####
###################################################

def pull_reviews(restaurant_df):
    """function to scrape yelp reviews with yelp api. Nested JSON and lists, so used loop
       only can pull a max of three reviews"""
    # loop through each restaurant id and pull reviews
    review_list = [[requests.get("https://api.yelp.com/v3/businesses/%s/reviews" % x,
                                 headers=headers).json(),x] for x in list(restaurant_df['id'])]
    
    return review_list


def reformat_reviews(review_list):
    """function to scrape yelp reviews from yelp api data. Nested JSON and lists, so used loop"""
    review_final = []
    for x in range(len(review_list)):
        review_id = review_list[x][1]
        try:
            review_slice = review_list[x][0]['reviews']
            for y in range(len(review_slice)):
                review_final = review_final + [[review_id, review_slice[y]['text'],
                                                review_slice[y]['time_created'],review_slice[y]['url'],
                                                review_slice[y]['id']]]
        except KeyError:
            #any errors on yelp side will be skipped
            print([[review_id, 'INTERNAL_YELP_ERROR','','','']])             
    return pd.DataFrame(review_final,columns=['id','review_text','review_date','review_url','review_id'])

#######################
## Run all and merge ##
#######################

def scrape_main(zip_code):
    """pull restaurants in/around zip code and merge on respective reviews"""
    restaurant_df = pull_businesses(zip_code,business_type='restaurants')  
    review_list = pull_reviews(restaurant_df)
    review_df = reformat_reviews(review_list)
    final_df = pd.merge(restaurant_df,review_df,how='left',on='id')
    final_df = final_df.replace(np.nan, '', regex=True)
    
    return final_df

###########################################
#### Functions to clean up merged data ####
###########################################


def add_latitude_longitude(final_df):
    """separate out coordinate json into separate columns"""
    final_df['latitude']=final_df['coordinates'].apply(lambda x: x['latitude'] if 'latitude' in x else '')
    final_df['longitude']=final_df['coordinates'].apply(lambda x: x['longitude'] if 'longitude' in x else '')
    return final_df


def add_address(final_df):
    """separate out address json into separate columns"""

    final_df['address1']=final_df['location'].apply(lambda x: x['address1'] if 'address1' in x else '')
    final_df['address2']=final_df['location'].apply(lambda x: x['address2'] if 'address1' in x else '')
    final_df['address3']=final_df['location'].apply(lambda x: x['address3'] if 'address1' in x else '')
    final_df['city']=final_df['location'].apply(lambda x: x['city'] if 'city' in x else '')
    final_df['state']=final_df['location'].apply(lambda x: x['state'] if 'state' in x else '')
    final_df['zip_code']=final_df['location'].apply(lambda x: x['zip_code'] if 'zip_code' in x else '')
    final_df['country']=final_df['location'].apply(lambda x: x['country'] if 'country' in x else '')
    final_df['display_address']=final_df['location'].apply(lambda x: ', '.join(x['display_address'])
                                                           if 'display_address' in x else '')
        
    return final_df

def transactions(final_df):
    """separate out transaction list values into separate columns""" 
    final_df['delivery'] = final_df['transactions'].apply(lambda x: 1 if 'delivery' in x else '')
    final_df['pickup'] = final_df['transactions'].apply(lambda x: 1 if 'pickup' in x else '')
    
    return final_df

def restaurant_categories(final_df):
    """create concatenated list of restaurant categories from json"""
    final_df['restaurant_categories'] = final_df['categories'].apply(lambda x: ', '.join([y['title'] for y in x]))
    return final_df

def remove_columns(final_df):
    """remove unnecessary columns"""
    final_df.drop(columns=['alias','coordinates',
                           'image_url','location',
                           'phone','transactions','categories'],inplace=True)
    
    return final_df


def clean_main(final_df):
    """run all cleanup on restaurant/review df"""
    final_df = add_latitude_longitude(final_df)
    final_df = add_address(final_df)
    final_df = transactions(final_df)
    final_df = restaurant_categories(final_df)
    final_df = remove_columns(final_df)
    
    return final_df
import customfunctions
import pandas_gbq
import pandas as pd
import gcsfs
from google.api_core.client_options import ClientOptions
from google.cloud import automl_v1, bigquery

# create BigQuery client
sentence_sentiment_client = bigquery.Client()

options = ClientOptions(api_endpoint='automl.googleapis.com')  
prediction_client = automl_v1.PredictionServiceClient(client_options=options)

# Developer: Edit Here
projectvar = 'YOUR-ID'

def classifier(data, context):

	# Developer: Edit Here
	final_df = pd.read_csv("gs://YOUR-BUCKET/YOUR/DIRECTORIES/final_df.csv")

	# label classification
	# Developer: Edit Here
	model_key = 'YOUR-MODEL-KEY'
	project_id = 'YOUR-ID'
	model_name = customfunctions.pull_model_name(model_key,project_id)
	final_df = customfunctions.multiprocess_label(df=final_df, model_name=model_name, prediction_client=prediction_client, text_column='review_text', classification_score=.7)
	
	final_df_ordered = final_df[['id', 'name', 'is_closed', 'url', 'review_count', 'rating', 'price', 'display_phone', 'distance', 'review_text', 'review_date', 'review_url', 'review_id', 'latitude', 'longitude', 'address1', 'address2', 'address3', 'city', 'state', 'zip_code', 'country', 'display_address', 'delivery', 'pickup', 'restaurant_categories', 'timestamp', 'sentiment_score', 'sentiment_magnitude', 'classification_labels']]
	
	# write dataframe to BigQuery using pandas gbq
	# Developer: Edit Here
	pandas_gbq.to_gbq(final_df_ordered,'YOUR-DATASET.YOUR-TABLE', project_id='YOUR-ID', 
                      if_exists='append')

	fs = gcsfs.GCSFileSystem(project=projectvar)
	# Developer: Edit Here
	fs.rm("gs://YOUR-BUCKET/YOUR/DIRECTORIES/final_df.csv")
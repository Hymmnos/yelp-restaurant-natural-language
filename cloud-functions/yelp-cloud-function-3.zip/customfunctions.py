import multiprocessing as mp
import sys
from google.api_core.client_options import ClientOptions
from google.cloud import automl_v1
from google.cloud.automl_v1.proto import service_pb2
import numpy as np
import pandas as pd

########################################################
#### Functions for Google's classification labeling ####
########################################################

# instantiate prediction client
options = ClientOptions(api_endpoint='automl.googleapis.com')  
prediction_client = automl_v1.PredictionServiceClient(client_options=options)

def pull_model_name(model_key,project_id):
    """look at models and find model_name (includes a project_id and model_key)"""
    from google.cloud import automl_v1beta1 as automl
    tables_client = automl.TablesClient(project=project_id, region="us-central1")
    list_models = tables_client.list_models()
    models = {model.display_name: model.name for model in list_models}
    model_name = models[model_key]
    
    return model_name

def inline_text_payload(text):
    """modify payload into necessary dict format"""
    return {'text_snippet': {'content': text, 'mime_type': 'text/plain'}}

#TODO, should separate out prediction from generating columns like in sentiment. Here its just wrapped together
def get_label_prediction(df, model_name, prediction_client,text_column, classification_score, output):
    """create classification predication column and filter by confidence to create final_labels. Filter by 
    classification threshold score"""
    df['payload_dict'] = df[text_column].apply(lambda x: inline_text_payload(x))
    params = {}
    df['prediction'] = df['payload_dict'].apply(lambda payload: prediction_client.predict(model_name, payload, params))
    df['classification_labels'] = df['prediction'].apply(lambda pay_load: ', '.join(
        [x.display_name for x in pay_load.payload if x.classification.score >= classification_score]))
    df.drop(columns=['prediction','payload_dict'],inplace=True)

    output.put(df)
    
def multiprocess_label(df,model_name=None,func=get_label_prediction, prediction_client=None,
                          text_column=None,classification_score=None,label=False):
        
    output = mp.Queue()
    
    processes = [mp.Process(target=func, args=(f, 
                                               model_name, 
                                               prediction_client,
                                               text_column, 
                                               classification_score, 
                                               output)) for f in np.array_split(df,4)]
    
    for p in processes:
        p.start()

    final_return = pd.concat([output.get() for p in processes])
    
    return final_return